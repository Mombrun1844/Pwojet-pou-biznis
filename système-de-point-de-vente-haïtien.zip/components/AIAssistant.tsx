import React, { useState, useContext, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { AppContext } from '../App';
import Modal from './shared/Modal';
import { Sparkles, Send } from 'lucide-react';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

const AIAssistant: React.FC = () => {
  const { products, sales, categories } = useContext(AppContext);
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: "Bonjour! Je suis votre assistant IA. Posez-moi des questions sur vos ventes, produits ou bénéfices. Par exemple : 'Quel est mon produit le plus rentable ?' ou 'Donne-moi un résumé des ventes de la semaine dernière.'",
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = { role: 'user', text: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const context = `
        Voici les données actuelles du point de vente:
        - Catégories: ${JSON.stringify(categories.map(c => ({ name: c.name })))}
        - Produits: ${JSON.stringify(products.map(p => ({ name: p.name, stock: p.stock, salePrice: p.salePrice, purchasePrice: p.purchasePrice, totalSales: p.totalSales })))}
        - Ventes récentes (10 dernières): ${JSON.stringify(sales.slice(0, 10).map(s => ({ productName: s.productName, quantity: s.quantity, total: s.total, profit: s.profit, date: s.date })))}
      `;

      const prompt = `${context}\n\nQuestion de l'utilisateur: ${userMessage.text}`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: "Tu es un assistant expert pour un système de point de vente en Haïti. La monnaie est la Gourde Haïtienne (HTG). Réponds en français de manière concise et utile. Analyse les données JSON fournies pour répondre aux questions. Utilise des listes à puces ou des mises en forme simples pour une meilleure lisibilité. N'invente pas de données. Si les données ne te permettent pas de répondre, dis-le gentiment.",
        },
      });

      const modelMessage: ChatMessage = { role: 'model', text: response.text };
      setMessages((prev) => [...prev, modelMessage]);

    } catch (error) {
      console.error("Erreur avec l'API Gemini:", error);
      const errorMessage: ChatMessage = { role: 'model', text: "Désolé, une erreur s'est produite. Veuillez réessayer plus tard." };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-30 w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-blue-500 text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        aria-label="Ouvrir l'assistant IA"
      >
        <Sparkles size={28} />
      </button>

      <Modal isOpen={isOpen} onClose={() => setIsOpen(false)} title="Assistant IA">
        <div className="flex flex-col h-[60vh]">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs md:max-w-md lg:max-w-lg p-3 rounded-2xl ${
                    msg.role === 'user' 
                    ? 'bg-purple-600 text-white rounded-br-lg' 
                    : 'bg-slate-700 text-gray-200 rounded-bl-lg'
                }`}>
                  <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                  <div className="max-w-xs md:max-w-md lg:max-w-lg p-3 rounded-2xl bg-slate-700 text-gray-200 rounded-bl-lg">
                    <div className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                        <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{animationDelay: '200ms'}}></div>
                        <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{animationDelay: '400ms'}}></div>
                    </div>
                  </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
          <form onSubmit={handleSendMessage} className="p-4 border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Posez votre question..."
              className="flex-1 w-full bg-white/10 p-2 rounded-lg border border-white/20 focus:ring-purple-500 focus:border-purple-500"
              disabled={isLoading}
            />
            <button
              type="submit"
              className="p-3 rounded-lg bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 transition-colors"
              disabled={isLoading || !input.trim()}
              aria-label="Envoyer"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
      </Modal>
    </>
  );
};

export default AIAssistant;
